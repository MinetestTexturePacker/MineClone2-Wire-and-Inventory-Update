floatindev 0.3.1 by paramat
For latest stable Minetest back to 0.4.8
Depends default
Licenses: code WTFPL
