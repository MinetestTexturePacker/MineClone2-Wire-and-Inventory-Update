## Castle farm products

B: Philipbenr, DanDuncombe, FaceDeer

Licence: MIT

=-=-=-=-=-=-=-=-=-=

Contains farm products useful for decorating a castle:

* Hide wall and floor coverings
* Bound straw bale
* Straw training dummy
